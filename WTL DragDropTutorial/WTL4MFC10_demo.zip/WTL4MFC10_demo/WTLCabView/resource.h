//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WTLCabView.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDS_MSGBOX_TITLE                129
#define IDS_OPENFILE_FILTER             130
#define IDI_PREV_CAB                    201
#define IDI_NEXT_CAB                    202
#define IDS_FDICREATE_FAILED            256
#define IDS_FILE_NOT_FOUND              257
#define IDS_OPEN_CAB_ERROR              258
#define IDS_INVALID_CAB_ERROR           259
#define IDS_FDICOPY_FAILED              260
#define IDS_COLHDR_NAME                 261
#define IDS_COLHDR_TYPE                 262
#define IDS_COLHDR_SIZE                 263
#define IDS_COLHDR_DATE                 264
#define IDS_COLHDR_ATTRS                265
#define IDS_COLHDR_SPLIT                266
#define IDS_FROM_PREV_CAB               267
#define IDS_TO_NEXT_CAB                 268
#define IDC_VIEW_ICONS                  32772
#define IDC_VIEW_SMALL_ICONS            32774
#define IDC_VIEW_LIST                   32775
#define IDC_VIEW_DETAILS                32776
#define IDC_VIEW_TILES                  32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
